package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.User;

public interface UserRepository extends JpaRepository<User,Long>{

	public User findByEmailAndPassword(String email,String password);
	
	 @Query(value = "select * from  user u where u.role='User'",nativeQuery = true)
	 public List<User> findAllByRoleUser();
	 
	 @Query(value="select * from user u where u.email=?1",nativeQuery=true)
	 public User findByAccountEmail(String email);
	 
	 public User findByPhoneNumber(String phoneNumber);
	 
	 public User findByDrivingLicense(String drivingLicense);
	 
	 public User findByEmailAndLastName(String email,String lastName);
	 
	 public User findByEmailAndFavourite(String email,String favourite);
	 
}
