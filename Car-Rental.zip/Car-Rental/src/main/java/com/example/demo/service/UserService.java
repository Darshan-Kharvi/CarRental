package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.User;
public interface UserService {

	public List<User> getAllUsers() throws ExceptionFound;
	public User saveUser(User user);
	public User getUserById(Long userId);
	public List<User> removeUser(Long userId);
	public User updateUserById(Long userId,User user) throws ExceptionFound;
	public User login(User user);
	public List<User> getUsersOnly() throws ExceptionFound;
	public User findByEmail(String useremail);
	public User updatePassword(String email, String password);
	public User findByPhoneNumber(String phoneNumber);
	public User findByDrivingLicense(String drivingLicense);
	public User findByEmailAndFavourite(String email,String favourite);
}
