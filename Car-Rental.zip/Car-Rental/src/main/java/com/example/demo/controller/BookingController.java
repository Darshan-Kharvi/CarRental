package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Booking;
import com.example.demo.model.Car;
import com.example.demo.service.BookingService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/bookings")
public class BookingController {

	@Autowired
	private BookingService bookingService;
	
	@PostMapping
	public Booking addBooking1(@RequestBody Booking booking) {
		return bookingService.addBooking1(booking);
	}
	
	@PostMapping("/{userId}/{carId}")
	public Booking addBooking(@RequestBody Booking booking,@PathVariable("userId") Long userId,@PathVariable("carId") Long carId) {
		return bookingService.addBooking(booking,userId,carId);
	}
	
	@GetMapping
	public List<Booking> getAllBooking() throws ExceptionFound{
		return bookingService.getAllBooking();
	}
	
	@GetMapping("/getBookingById/{bookingId}")
	public Booking getBookingById(@PathVariable Long bookingId) {
		return bookingService.getBookingById(bookingId);
	}
	
	@GetMapping("/getBookingByUserId/{userId}")
	public List<Booking> getBookingByUserId(@PathVariable Long userId){
		return bookingService.getBookingByUserId(userId);
	}
	
	@GetMapping("/getBookingByCarId/{carId}")
	public List<Booking> getBookingByCarId(@PathVariable Long carId){
		return bookingService.getBookingByCarId(carId);
	}
	
	@DeleteMapping("/deleteBookingById/{bookingId}")
	public List<Booking> deleteBookingById(@PathVariable Long bookingId){
		return bookingService.deleteBookingById(bookingId);
	}
	
	@PutMapping("/updateBookingById/{bookingId}")
	public Booking updateBookingById(@PathVariable Long bookingId,@RequestBody Booking booking) throws ExceptionFound {
		return bookingService.updateBookingById(bookingId, booking);
	}
	
	@GetMapping("/getCarByBookingId/{bookingId}")
	public Long getCarByBookingId(@PathVariable Long bookingId) {
		return bookingService.getCarByBookingId(bookingId);
	}
}
