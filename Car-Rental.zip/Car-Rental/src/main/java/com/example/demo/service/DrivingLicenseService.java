package com.example.demo.service;

import com.example.demo.model.DrivingLicense;

public interface DrivingLicenseService {

	public DrivingLicense addLicense(DrivingLicense drivingLicense);
	public DrivingLicense getDlandNo(String dl,String phoneNo);
}
