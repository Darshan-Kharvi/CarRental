package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Booking;
//import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.User;
import com.example.demo.repository.BookingRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired 
	UserRepository userRepository;
	
	@Autowired
	BookingRepository bookingRepository;
	
	@Autowired
	private EmailService emailService;

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		
		//User newUser=user;
		String message="Hi <b>"+user.getFirstName()+" "+user.getLastName()+"</b>,<br>Congratulations You have registered Your "
				+ "Account "+user.getEmail()+" in Our CarRental Application ";
		String subject="Account Creation";
		emailService.sendEmail(user.getEmail(), subject, message);
		
		return userRepository.save(user);
	}

	@Override
	public User getUserById(Long userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId).get();
	}

	@Override
	public List<User> removeUser(Long userId) {
		// TODO Auto-generated method stub
		User user=getUserById(userId);
		List<Booking> bookingList=user.getBookings();
		for(Booking booking:bookingList) {
			booking.setUser(null);
			bookingRepository.save(booking);
		}
		//User oldUser=user;
		String message="Hi <b>"+user.getFirstName()+" "+user.getLastName()+"</b>,<br> I Regret to say that Your "
				+ "Account "+user.getEmail()+" Has been deleted By some issue ";
		String subject="Account Deleted";
		emailService.sendEmail(user.getEmail(), subject, message);
		userRepository.deleteById(user.getUserId());
		return userRepository.findAllByRoleUser();
	}

	@Override
	public User updateUserById(Long userId, User user) {
		// TODO Auto-generated method stub
		User existingUser=getUserById(userId);
		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		//existingUser.setEmail(user.getEmail());
		//existingUser.setPhoneNumber(user.getPhoneNumber());
		existingUser.setAddress(user.getAddress());
		//existingUser.setDrivingLicense(user.getDrivingLicense());
		//existingUser.setPassword(user.getPassword());
		return userRepository.save(existingUser);
	}

	@Override
	public User login(User user) {
		// TODO Auto-generated method stub
		return userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
	}

	@Override
	public List<User> getUsersOnly(){
		// TODO Auto-generated method stub
		return userRepository.findAllByRoleUser();
	}

	@Override
	public User findByEmail(String useremail) {
		// TODO Auto-generated method stub
		return userRepository.findByAccountEmail(useremail);
	}

	@Override
	public User updatePassword(String email, String password) {
		// TODO Auto-generated method stub
		User existingUser=userRepository.findByAccountEmail(email);
		existingUser.setPassword(password);
		
		return userRepository.save(existingUser);
	}

	@Override
	public User findByPhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		return userRepository.findByPhoneNumber(phoneNumber);
	}

	@Override
	public User findByDrivingLicense(String drivingLicense) {
		// TODO Auto-generated method stub
		return userRepository.findByDrivingLicense(drivingLicense);
	}

	@Override
	public User findByEmailAndFavourite(String email, String favourite) {
		// TODO Auto-generated method stub
		return userRepository.findByEmailAndFavourite(email, favourite);
	}

}
