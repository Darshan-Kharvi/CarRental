package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Booking;
import com.example.demo.model.Payment;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.service.BookingService;
import com.example.demo.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService{

	@Autowired
	private PaymentRepository paymentRepository;
	
	@Autowired
	private BookingService bookingService;

	@Override
	public Payment addPayment1(Payment payment) {
		// TODO Auto-generated method stub
		return paymentRepository.save(payment);
	}

	@Override
	public List<Payment> getAllPayment() {
		// TODO Auto-generated method stub
		return paymentRepository.findAll();
	}

	@Override
	public Payment getPaymentById(Long paymentId) {
		// TODO Auto-generated method stub
		return paymentRepository.findById(paymentId).get();
	}

	@Override
	public List<Payment> deletePayment(Long paymentId) {
		// TODO Auto-generated method stub
		Payment payment=getPaymentById(paymentId);
		paymentRepository.deleteById(payment.getPaymentId());
		return getAllPayment();
	}

	@Override
	public Payment updatePaymentById(Long paymentId, Payment payment) {
		// TODO Auto-generated method stub
		Payment existingPayment=getPaymentById(paymentId);
		existingPayment.setPaymentStatus(payment.getPaymentStatus());
		return paymentRepository.save(existingPayment);
	}

	@Override
	public Payment addPayment(Payment payment, Long BookingId) {
		// TODO Auto-generated method stub
		Booking booking=bookingService.getBookingById(BookingId);
		payment.setBooking(booking);
		return paymentRepository.save(payment);
	}

	@Override
	public Payment getPaymentByBookingId(Long bookingId) {
		// TODO Auto-generated method stub
		return paymentRepository.findByBookingBookingId(bookingId);
	}
	
}
