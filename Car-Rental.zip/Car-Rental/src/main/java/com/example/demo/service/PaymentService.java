package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Payment;

public interface PaymentService {
	
	public Payment addPayment1(Payment payment);
	public List<Payment> getAllPayment() throws ExceptionFound;
	public Payment getPaymentById(Long paymentId);
	public List<Payment> deletePayment(Long paymentId);
	public Payment updatePaymentById(Long paymentId,Payment payment) throws ExceptionFound;
	public Payment addPayment(Payment payment,Long bookingId);
	public Payment getPaymentByBookingId(Long bookingId);
}
