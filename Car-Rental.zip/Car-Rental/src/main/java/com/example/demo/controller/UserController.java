package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.User;
import com.example.demo.service.UserService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping
	public User saveUser(@RequestBody User user) {
		return userService.saveUser(user);
	}
	
	@GetMapping
	public List<User> getAllUser() throws ExceptionFound{
		return userService.getAllUsers();
	}
	
	@GetMapping("/getUserById/{userId}")
	public User getUserById(@PathVariable Long userId) {
		return userService.getUserById(userId);
	}
	
	@DeleteMapping("/deleteUser/{userId}")
	public List<User> deleteUserById(@PathVariable Long userId){
		return userService.removeUser(userId);
	}
	
	@PutMapping("/{userId}")
	public User updateUser(@PathVariable Long userId,@RequestBody User user) throws ExceptionFound {
		return userService.updateUserById(userId, user);
	}
	
	@PostMapping("/login")
	public ResponseEntity<User> loginUser(@RequestBody User user) {
		return new ResponseEntity<User>(userService.login(user),HttpStatus.OK);
	}
	
	@GetMapping("/userrole")
	public List<User> getUserOnly() throws ExceptionFound{
		return userService.getUsersOnly();
	}
	
	@GetMapping("/findbyemail/{usermail}")
	public User getUserByEmail(@PathVariable("usermail") String usermail) {
		return userService.findByEmail(usermail);
	}
	
	@PutMapping("/updatepass/{usermail}/{password}")
	public User updatePassword(@PathVariable("usermail") String usermail,@PathVariable("password") String password) {
		return userService.updatePassword(usermail, password);
	}
	
	@GetMapping("/findbyphone/{ph}")
	public User getUserByPhoneNo(@PathVariable("ph") String phoneNumber) {
		return userService.findByPhoneNumber(phoneNumber);
	}
	
	@GetMapping("/findbydl/{dl}")
	public User getUserByDL(@PathVariable("dl") String drivingLincense) {
		return userService.findByDrivingLicense(drivingLincense);
	}
	
	@GetMapping("/findByFavourite/{email}/{favourite}")
	public User getUserByEmailAndLastName(@PathVariable("email") String email,@PathVariable("favourite") String favourite) {
		return userService.findByEmailAndFavourite(email, favourite);
	}
	
}
