package com.example.demo.service;

import com.example.demo.model.BankServer;

public interface BankServerService {

	public BankServer saveDetails(BankServer bankServer);
	public BankServer findByCardCvv(Long cCardnumber, Integer cCvvnumber, String expiryDate);
	public BankServer findByUpi(String cUpi);
	public BankServer cardValidation(BankServer bankServer);
	public BankServer findCardNumber(Long cCardnumber);
}
