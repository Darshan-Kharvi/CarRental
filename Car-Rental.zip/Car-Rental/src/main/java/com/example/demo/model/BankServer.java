package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BankServer {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(unique=true)
	private Long cCardnumber;
	
	@Column(unique=true)
	private Integer cCvvnumber;
	
	@Column(unique=true)
	private String cUpi;
	
	private String expiryDate ;
	
	private String cCardholdername;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getcCardnumber() {
		return cCardnumber;
	}

	public void setcCardnumber(Long cCardnumber) {
		this.cCardnumber = cCardnumber;
	}

	public Integer getcCvvnumber() {
		return cCvvnumber;
	}

	public void setcCvvnumber(Integer cCvvnumber) {
		this.cCvvnumber = cCvvnumber;
	}

	public String getcUpi() {
		return cUpi;
	}

	public void setcUpi(String cUpi) {
		this.cUpi = cUpi;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getcCardholdername() {
		return cCardholdername;
	}

	public void setcCardholdername(String cCardholdername) {
		this.cCardholdername = cCardholdername;
	}
	
}
