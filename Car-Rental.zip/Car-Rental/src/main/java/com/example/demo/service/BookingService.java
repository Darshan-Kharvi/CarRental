package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Booking;
import com.example.demo.model.Car;

public interface BookingService {

	public Booking addBooking1(Booking booking);
	public List<Booking> getAllBooking() throws ExceptionFound;
	public Booking getBookingById(Long bookingId);
	public List<Booking> getBookingByUserId(Long userId);
	public List<Booking> deleteBookingById(Long bookingId);
	public Booking updateBookingById(Long bookingId,Booking booking) throws ExceptionFound;
	public List<Booking> getBookingByCarId(Long carId);
	public Booking addBooking(Booking booking,Long userId,Long carId);
	public Long getCarByBookingId(Long bookingId);
}
