package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Car;

public interface CarRepository extends JpaRepository<Car,Long>{

	@Query(value = "select * from  car c where c.availability='Available'",nativeQuery = true)
	public List<Car> findAllByAvailability();
	
	//public Car findByBookingBookingId(Long bookingId);
	@Query(value = "SELECT * FROM car WHERE car_no = ?1", nativeQuery = true)
	public Car findByCarNo(String carNo);
}
