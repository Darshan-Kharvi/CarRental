package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.DrivingLicense;
import com.example.demo.repository.DrivingLicenseRepository;
import com.example.demo.service.DrivingLicenseService;

@Service
public class DrivingLicenseServiceImpl implements DrivingLicenseService{
	
	@Autowired
	private DrivingLicenseRepository drivingLicenseRepository;

	@Override
	public DrivingLicense addLicense(DrivingLicense drivingLicense) {
		// TODO Auto-generated method stub
		return drivingLicenseRepository.save(drivingLicense);
	}

	@Override
	public DrivingLicense getDlandNo(String dl, String phoneNo) {
		// TODO Auto-generated method stub
		return drivingLicenseRepository.findByDrivingLicenseNoAndPhoneNumber(dl, phoneNo);
	}

}
