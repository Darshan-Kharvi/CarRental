package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class DrivingLicense {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long drivingLicenseId;
	
	@Column(unique = true)
	private String drivingLicenseNo;
	
	@Column(unique = true)
	private String phoneNumber;

	public String getDrivingLicenseNo() {
		return drivingLicenseNo;
	}

	public void setDrivingLicenseNo(String drivingLicenseNo) {
		this.drivingLicenseNo = drivingLicenseNo;
	}

	public Long getDrivingLicenseId() {
		return drivingLicenseId;
	}

	public void setDrivingLicenseId(Long drivingLicenseId) {
		this.drivingLicenseId = drivingLicenseId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
}
