package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.exception.ExceptionFound;
import com.example.demo.model.Car;
import com.example.demo.model.User;
import com.example.demo.service.CarService;
import com.example.demo.service.UserService;


@SpringBootTest
class CarRentalApplicationTests {

	@Autowired
	private CarService carService;
	
	//static private Car car;
	@Disabled
	@Test
	public void addCar() {
		Car car =new Car();
		car.setAvailability("Available");
		car.setBrand("Tata");
		car.setCarLink("https://img.autocarindia.com/Galleries/20190115125713_19-12-34frontsilver.jpg");
		car.setMileage(14);
		car.setName("Nexon");
		car.setRentalPrice(700);
		car.setSeat(5);
		car.setYear(2019);
		Car car1=this.carService.addCar(car);
		assertNotNull(car1);
	}
	
	
	@Test
	public void checkAvailability() {
		Car car=new Car();
		car=this.carService.getCarById((long) 7);
		assertEquals("Available",car.getAvailability());
	}
	
	@Test
	public void testCarCount() throws ExceptionFound {
		List<Car> carList=this.carService.getAllCar();
		assertTrue(carList.size()>0);
	}
	
	@Test
	void contextLoads() {
	}

}
