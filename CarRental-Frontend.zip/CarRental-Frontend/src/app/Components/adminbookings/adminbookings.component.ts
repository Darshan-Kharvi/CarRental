import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-adminbookings',
  standalone: false,
  templateUrl: './adminbookings.component.html',
  styleUrl: './adminbookings.component.css'
})
export class AdminbookingsComponent implements OnInit{

  constructor(private adminService:AdminService){}

  //bookings:any[]=[];
  p:number=1;
  count:number=5;
  bookings:any;

  ngOnInit(): void {
      /*this.adminService.getAllBooking().subscribe(
        (response:any)=>{
          for (let booking of response) {
            if (booking.car !== null) {
              this.bookings.push(booking);
            }
          }
        }
      )*/

        this.adminService.getAllBooking().subscribe(
          (response:any)=>{
            console.log(response);
            this.bookings=response;
          })
  }

}
