import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-adminaccounts',
  standalone: false,
  templateUrl: './adminaccounts.component.html',
  styleUrl: './adminaccounts.component.css'
})
export class AdminaccountsComponent implements OnInit{

  constructor(private adminService:AdminService){}

  users:any;


  ngOnInit(): void {
      this.adminService.getAllByUserRole().subscribe(
        (response:any)=>{
          this.users=response
        }
      )
  }

  deleteUserById(userId:any){
    this.adminService.deleteUserById(userId).subscribe(
      (response:any)=>{
        this.users=response
      }
    )
  }

}
