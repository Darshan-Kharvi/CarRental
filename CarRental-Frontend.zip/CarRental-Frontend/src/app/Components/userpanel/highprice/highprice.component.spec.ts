import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HighpriceComponent } from './highprice.component';

describe('HighpriceComponent', () => {
  let component: HighpriceComponent;
  let fixture: ComponentFixture<HighpriceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HighpriceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HighpriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
