import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../Services/admin.service';
import { CarService } from '../../Services/car.service';
import { Router } from '@angular/router';
import { Booking } from '../../model/Booking';
import { BookingService } from '../../Services/booking.service';

@Component({
  selector: 'app-admincar',
  standalone: false,
  templateUrl: './admincar.component.html',
  styleUrl: './admincar.component.css'
})
export class AdmincarComponent implements OnInit{

  constructor(private adminService:AdminService,private carService:CarService,private router:Router,
    private bookingService:BookingService
  ){}

  bookings:any[]=[];
  cars:any;
  //endDate: any;
  todayDate:string="";

  ngOnInit(): void {

    this.adminService.getAllBooking().subscribe(
      (response:any)=>{
        for (let booking of response) {
          if (booking.car !== null) {
            //this.bookings.push(booking);
            const today = new Date();
            this.todayDate = today.toISOString().split('T')[0];
            if(booking.endDate<this.todayDate){
              this.carService.updateCarAvailability(booking.car.carId, "Available").subscribe((response: any) => {
                //this.car = response;
              });
            }else{
              this.carService.updateCarAvailability(booking.car.carId, "Not Available").subscribe((response: any) => {
                //this.car = response;
              });
            }
          }
        }
      }
    )

      this.carService.getAllCars().subscribe(
        (response:any)=>{
          console.log(response)
          this.cars=response
        }
      )


  }

  deleteCarById(carId:any){
    this.carService.deleteCarById(carId).subscribe(
      (response:any)=>{
        this.cars=response
      }
    )
  }

  updateCarById(carId:any){
    //sessionStorage.setItem('carId',carId)
    this.router.navigate(['updatecarurl',carId])
  }

  addCar(){
    this.router.navigate(['addcar'])
  }

}
