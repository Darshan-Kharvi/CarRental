import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { UserService } from '../../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../../Services/authentication.service';

@Component({
  selector: 'app-forgotpassword',
  standalone: false,
  templateUrl: './forgotpassword.component.html',
  styleUrl: './forgotpassword.component.css'
})
export class ForgotpasswordComponent implements OnInit{

  constructor(private userService:UserService,private router:Router,private authenticationService:AuthenticationService,
    private activatedRoute:ActivatedRoute
  ){}

  user=new User();
  //accountPassword:any;
  confirmPassword:string="";

  ngOnInit(): void {
      this.user.email=this.activatedRoute.snapshot.params['usermail']
  }

  updatepass(){
    console.log(this.user.email);
    this.userService.forgotpass(this.user.email).subscribe(
      (response:any)=>{
        if(response!=null){
          console.log(response)
          if(this.confirmPassword==this.user.password){
            console.log("I am Here")
            this.authenticationService.validateUserAndFavourite(this.user.email,this.user.favourite).subscribe(
              (response:any)=>{
                console.log("Not Executing")
                if(response!=null){
                  this.userService.updatePassword(this.user.email,this.user.password).subscribe(
                    (response:any)=>{
                      alert("Password Changed Successfully")
                      this.router.navigate(['loginurl'])
                    }
                  )
                }else{
                  alert("User Email and Favourite Place Does not Match")
                }
              }
            )             
          }else{
            alert("Password and Confirm Password does not Match")
          }
        }else{
          alert("EmailId does not exist")
        }
      }
    )
  }  
}
