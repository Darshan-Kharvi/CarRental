import { Component, OnInit } from '@angular/core';
import { User } from '../../model/User';
import { UserService } from '../../Services/user.service';
import { CarService } from '../../Services/car.service';
import { AdminService } from '../../Services/admin.service';


@Component({
  selector: 'app-adminpanel',
  standalone: false,
  templateUrl: './adminpanel.component.html',
  styleUrl: './adminpanel.component.css'
})
export class AdminpanelComponent implements OnInit {

  user = new User();
  cars: any[] = [];
  users: any[] = [];
  pagedCars: any[] = [];
  currentPage: number = 0;
  pageSize: number = 6;
  userId: any;
  totalPages: number = 0;

  // Image slideshow
  images: string[] = [
    'https://coolwallpapers.me/th700/2619394-cars-4k-wallpaper-hd-free.jpg',
    'https://coolwallpapers.me/th700/2817935-car-muscle-cars-rally-cars-bmw___cars-wallpapers.jpg',
    'https://coolwallpapers.me/th700/2817934-car-muscle-cars-rally-cars-bmw___cars-wallpapers.jpg',
    'https://coolwallpapers.me/th700/5019975-muscle-cars-chevrolet-cars-hd.jpg'
  ];
  currentIndex = 0;
  currentCarIndex = 0;

  stats = [
    { label: 'Total Cars', value: 0 },
    { label: 'Available Cars', value: 0 },
    { label: 'Rented Cars', value: 0 },
    { label: 'Total Users', value: 0 }
  ];

  constructor(
    private carService: CarService,
    private adminService: AdminService,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.loadCars();
    this.loadUsers();
    this.loadUserInfo();
    this.startImageSlideshow();
    this.loadUserDetails();

    this.userId=sessionStorage.getItem('userId');
    this.userService.getUserById(this.userId).subscribe(
      (respone:any)=>{
        this.user=respone
      }
    )
    this.carService.getAllCars().subscribe((data: any) => {
      this.cars = data;
      this.updatePagedCars();
      this.startSlideshow();
    });
  }

  loadCars() {
    this.carService.getAllCars().subscribe((data: any) => {
      this.cars = data;

      // Calculate the total number of pages
      this.totalPages = Math.ceil(this.cars.length / this.pageSize); // Calculate total pages

      const availableCars = data.filter((car: any) => car.availability === 'Available').length;
      const unavailableCars = data.length - availableCars;

      this.stats[0].value = data.length;
      this.stats[1].value = availableCars;
      this.stats[2].value = unavailableCars;

      if (this.cars.length > 0) {
        setInterval(() => this.nextCarSlide(), 5000);
      }

      this.updatePagedCars();
    });
  }


  loadUsers() {
    this.adminService.getAllByUserRole().subscribe((data: any) => {
      this.users = data;
      this.stats[3].value = data.length;
    });
  }

  loadUserInfo() {
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
    }
  }

  loadUserDetails() {
    this.userId = sessionStorage.getItem('userId');
    if (this.userId) {
      this.userService.getUserById(this.userId).subscribe((response: any) => {
        this.user = response;
      });
    }
  }

  startImageSlideshow() {
    setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.images.length;
    }, 5000);
  }

  nextCarSlide() {
    this.currentCarIndex = (this.currentCarIndex + 1) % this.cars.length;
  }

  updatePagedCars() {
    const startIndex = this.currentPage * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.pagedCars = this.cars.slice(startIndex, endIndex);
  }

  nextPage() {
    if ((this.currentPage + 1) * this.pageSize < this.cars.length) {
      this.currentPage++;
      this.updatePagedCars();
    }
  }

  prevPage() {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.updatePagedCars();
    }
  }

  startSlideshow() {
    setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.images.length;
    }, 3000);
  }
}
