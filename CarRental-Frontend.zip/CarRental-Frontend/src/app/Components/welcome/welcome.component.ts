import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { CarService } from '../../Services/car.service';
import { UserService } from '../../Services/user.service';

@Component({
  selector: 'app-welcome',
  standalone: false,
  templateUrl: './welcome.component.html',
  styleUrl: './welcome.component.css'
})
export class WelcomeComponent implements OnInit {

  cars: any[] = [];
  currentCarIndex = 0;
  logedIn:boolean=false;
  userId:any;
  user:any
  constructor(private carService: CarService, private router: Router,private userSrevice:UserService) {}


  ngOnInit(): void {
    this.userId=sessionStorage.getItem('userId')
    if(this.userId!=null){
      this.logedIn=true
    }else{
      this.logedIn=false
    }
    this.carService.getAllCars().subscribe((data:any) => {
      this.cars = data;

      // Start auto slide only if there are cars
      if (this.cars.length > 0) {
        setInterval(() => this.nextSlide(), 5000);
      }
    });
  }
  nextSlide() {
    this.currentCarIndex = (this.currentCarIndex + 1) % this.cars.length;
  }
  prevSlide() {
    this.currentCarIndex = (this.currentCarIndex - 1 + this.cars.length) % this.cars.length;
  }


  bookCar() {
  
    this.router.navigate(['loginurl']);
  }

  //foter scroll
  @ViewChild('footerRef') footerRef!: ElementRef;
  scrollToFooter() {
    this.footerRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  @ViewChild('headerRef') headerRef!: ElementRef;
scrollToHeader() {
  this.headerRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

@ViewChild('sectionRef') sectionRef!: ElementRef;

scrollToSection() {
  this.sectionRef.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

handleBrowseCars() {
  if(this.userId!=null){
    this.userSrevice.getUserById(this.userId).subscribe(data=>{
      this.user=data;
    }
    )
    if(this.user.role=='admin'){
      this.router.navigate(['adminurl'])
    }else{
      this.router.navigate(['userurl'])
    }

  }else{
    this.router.navigate(['/loginurl']);
  }
  
  

}

onCarImageClick(){
  if(this.userId==null){
    alert("Please login to book a car")
    this.router.navigate(['/loginurl']);
  }   else{
    this.router.navigate(['/usercars']);
  }
}
}




