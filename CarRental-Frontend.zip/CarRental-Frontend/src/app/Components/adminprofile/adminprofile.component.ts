import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../../model/User';
import { AdminService } from '../../Services/admin.service';

@Component({
  selector: 'app-adminprofile',
  standalone: false,
  templateUrl: './adminprofile.component.html',
  styleUrl: './adminprofile.component.css'
})
export class AdminprofileComponent implements OnInit{

  admin=new User();
  userId:any;
  constructor(private router:Router,private adminService:AdminService){}

  ngOnInit(): void {
     this.userId=sessionStorage.getItem('userId')
     this.adminService.getUserById(this.userId).subscribe(
      (response:any)=>{
        this.admin=response
      }
     )
  }

  onUpdate(){
    this.adminService.updateUser(this.admin,this.userId).subscribe(
      (response:any)=>{
        alert("Updated Successfully")
        this.admin=response
        this.router.navigate(['adminurl'])
      }
    )
  }

  onLogout(){
    sessionStorage.removeItem('userId')
    alert("Logout Successfull")
    this.router.navigate(['loginurl'])
  }
}
