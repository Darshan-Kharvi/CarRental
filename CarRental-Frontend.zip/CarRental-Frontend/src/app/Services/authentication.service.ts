import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private httpClient:HttpClient) { }

  url="http://localhost:8030/api/users"
  dl="http://localhost:8030/api/dl/validate"

  public isUserLoggedIn(){
    let userId=sessionStorage.getItem('userId')
    return !(userId==null)
  }
  
  checkEmail(email:any){
    return this.httpClient.get(`${this.url}/findbyemail/${email}`)
  }

  checkPhoneNumber(phoneNumber:any){
    return this.httpClient.get(`${this.url}/findbyphone/${phoneNumber}`)
  }

  checkDL(dl:any){
    return this.httpClient.get(`${this.url}/findbydl/${dl}`)
  }

  validateDlAndPhone(dl:any,phoneno:any){
    return this.httpClient.get(`${this.dl}/${dl}/${phoneno}`);
  }

  validateUserAndFavourite(email:any,favourite:any){
    return this.httpClient.get(`${this.url}/findByFavourite/${email}/${favourite}`)
  }

}
