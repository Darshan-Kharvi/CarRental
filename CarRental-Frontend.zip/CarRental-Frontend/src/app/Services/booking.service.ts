import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private httpClient:HttpClient) { }

  url="http://localhost:8030/api/bookings"

  addBooking(booking:any,carId:any,userId:any){
    return this.httpClient.post(`${this.url}/${userId}/${carId}`,booking)
  }

  getBooking(bookingId:any){
    return this.httpClient.get(`${this.url}/getBookingById/${bookingId}`)
  }

}
