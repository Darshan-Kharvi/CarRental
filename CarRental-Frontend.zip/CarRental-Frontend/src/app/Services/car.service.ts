import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor(private httpClient:HttpClient) { }

  url="http://localhost:8030/api/cars"
  car:any;

  getAllCars(){
    return this.httpClient.get(`${this.url}`)
  }

  deleteCarById(carId:any){
    return this.httpClient.delete(`${this.url}/deleteCarById/${carId}`)
  }

  addCar(car:any){
    return this.httpClient.post(`${this.url}`,car)
  }

  getCarById(carId:any){
    return this.httpClient.get(`${this.url}/getCarById/${carId}`)
  }

  updateCarById(carId:any,car:any){
    return this.httpClient.put(`${this.url}/updateCarById/${carId}`,car)
  }

  getAvailableCar(){
    return this.httpClient.get(`${this.url}/getCarByAvailability`)
  }

  updateCarAvailability(carId:any,availability:any){
    return this.httpClient.put(`${this.url}/updateCarAvailability/${carId}/${availability}`,this.car)
  }
}