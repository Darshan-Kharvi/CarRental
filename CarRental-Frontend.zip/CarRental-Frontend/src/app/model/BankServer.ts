export class BankServer{
    id:number|null;
    cCardnumber:string;
    cCvvnumber:string;
    cUpi:string;
    expiryDate:string;
    cCardholdername:string;

    constructor(){
        this.id=null;
        this.cCardnumber="";
        this.cCvvnumber="";
        this.cUpi="";
        this.expiryDate="";
        this.cCardholdername="";
    }
}