export class Payment{
    paymentId:any;
    paymentDate:Date;
    paymentStatus:any;
    cardholderName:any;
    paymentAmount:any;

    constructor(){
        this.paymentDate=new Date();
        this.paymentStatus="Processing";
        this.cardholderName="";
        this.paymentAmount=""
    }

}