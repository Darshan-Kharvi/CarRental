export class Booking{
    bookingId:any;
    startDate:Date;
    endDate:Date;
    address:any;
    totalCost:number|null;

    constructor(){
        this.startDate=new Date();
        this.endDate=new Date();
        this.address="";
        this.totalCost=0;
    }

}